
function getLogin(){
  var info =sessionStorage.getItem('access');
    $.ajax({
        type:"post",
        url:"/getConfig",
        data:info,
        success:function(data){
           jsonobj= data;
           var logo=jsonobj.syscontrol[0].display_log;
           if(logo==1){
                $("#Falcon_Admin").show();
                $("#logo_chinese").hide();
                $("#QQ_logo").show();
                document.title = 'rtsp转rtmp推流器';
           }else if(logo==0){
                $("#Falcon_Admin").hide();
                $("#logo_chinese").hide();
           }else if(logo==2){
                $("#Falcon_Admin").hide();
                $("#logo_chinese").show();
                document.title = '金和智能转码器';
           }else if(logo==3){
                $("#Falcon_Admin_1").show();
                $("#logo_chinese").hide();
                $("#QQ_logo_1").show();
                document.title = '政凯秀直播';
           }else if(logo==4){
                $("#Falcon_Admin_2").show();
                $("#logo_chinese").hide();
                $("#QQ_logo_2").show();
                document.title = '同位onvif推流器';
           }
        }
    })
}
getLogin()