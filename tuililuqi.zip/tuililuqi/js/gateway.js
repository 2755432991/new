$(function(){
	var info = sessionStorage.getItem('access');
	$.ajax({
			type:"post",
			url:"/getConfig",
			data:info,
	   		success:function(data){
	   			  jsonobj= data;
	   			  var enable = jsonobj.ipinfo[0].local_net.enable;
	   			  if(enable == 0){
	   			  	 $("#enablegetway").css("display","none");
	   			  }else if(enable == 1){
	   			  	 $("#enablegetway").css("display","block");
	   			  }
	          
	   	  }
	})	
})